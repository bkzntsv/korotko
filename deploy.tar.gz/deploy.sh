#!/bin/bash

# Скрипт для развертывания проекта на сервере
# Использование: ./deploy.sh [user@]host

set -e

SERVER="${1:-root@80.92.206.165}"
REMOTE_DIR="/opt/ochemeto"

echo "🚀 Начинаю развертывание на сервер $SERVER"

# Проверка наличия .env файла
if [ ! -f .env ]; then
    echo "❌ Файл .env не найден!"
    echo "Создайте файл .env на основе env.template:"
    echo "  cp env.template .env"
    echo "  nano .env  # и заполните значения"
    exit 1
fi

# Проверка переменных окружения
if ! grep -q "TELEGRAM_BOT_TOKEN=" .env || ! grep -q "OPENAI_API_KEY=" .env; then
    echo "❌ В файле .env отсутствуют обязательные переменные!"
    exit 1
fi

echo "📦 Создаю архив проекта..."
# Отключаем создание метаданных macOS (._ файлы)
export COPYFILE_DISABLE=1
tar --exclude='.git' \
    --exclude='build' \
    --exclude='.gradle' \
    --exclude='.idea' \
    --exclude='*.iml' \
    --exclude='.DS_Store' \
    --exclude='*.log' \
    -czf deploy.tar.gz .

echo "📤 Загружаю файлы на сервер..."
ssh -T $SERVER "mkdir -p $REMOTE_DIR"
scp deploy.tar.gz $SERVER:$REMOTE_DIR/
scp .env $SERVER:$REMOTE_DIR/

echo "🏗️  Распаковываю и собираю проект на сервере..."
ssh -T $SERVER << EOF
set -e
cd $REMOTE_DIR

echo "Распаковываю архив..."
tar -xzf deploy.tar.gz
rm deploy.tar.gz

echo "Настраиваю Docker и Docker Compose..."

# Функция для определения команды docker-compose
if docker compose version &> /dev/null; then
    DC="docker compose"
elif command -v docker-compose &> /dev/null; then
    DC="docker-compose"
else
    echo "Docker Compose не найден. Устанавливаю standalone версию..."
    curl -SL https://github.com/docker/compose/releases/download/v2.24.6/docker-compose-linux-x86_64 -o /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose
    DC="/usr/local/bin/docker-compose"
fi

echo "Использую команду: \$DC"

echo "Останавливаю старые контейнеры..."
\$DC down || true

echo "Собираю новый образ..."
\$DC build --no-cache

echo "Запускаю контейнер..."
\$DC up -d

echo "Проверяю статус..."
sleep 3
\$DC ps

echo "Показываю последние логи..."
\$DC logs --tail=50
EOF

echo "🧹 Очищаю локальные временные файлы..."
rm deploy.tar.gz

echo "✅ Развертывание завершено!"
echo "Для просмотра логов выполните: ssh $SERVER 'cd $REMOTE_DIR && docker compose logs -f' (или docker-compose logs -f)"
