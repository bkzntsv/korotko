# Design Document: Voice Transcription System

## 1. Overview

Модуль транскрибации предназначен для обработки голосовых сообщений (Voice) и аудиофайлов (Audio). Он выполняет роль "моста" между Telegram API, OpenAI Whisper и нашей существующей системой суммаризации.

**Ключевое решение:** Мы не сохраняем файлы на диск. Вся обработка (скачивание → передача в Whisper) происходит в оперативной памяти (In-Memory) через потоки байтов, чтобы ускорить работу и упростить деплой в Docker (не нужно возиться с volumes).

**Основной поток данных:**
1. Пользователь отправляет голосовое сообщение или аудиофайл
2. Bot скачивает файл в память через Telegram API
3. Аудио отправляется в OpenAI Whisper для транскрибации
4. Полученный текст анализируется на длину
5. Короткие тексты (<50 символов) возвращаются как есть
6. Длинные тексты передаются в существующий Summarizer
7. Результат форматируется и отправляется пользователю

## 2. Architecture (Component Diagram)

```mermaid
classDiagram
    class TelegramBotController {
        +setupHandlers()
        -handleVoice()
        -handleAudio()
    }
    
    class VoiceTranscriptionOrchestrator {
        <<Interface>>
        +processVoice(fileId: String) TranscriptionResult
    }
    
    class TranscriptionProvider {
        <<Interface>>
        +transcribe(bytes: ByteArray) String
    }
    
    class FileDownloader {
        <<Interface>>
        +download(fileId: String) ByteArray
    }
    
    class SummaryOrchestrator {
        <<Existing>>
        +summarizeText(text: String) Summary
    }
    
    TelegramBotController --> VoiceTranscriptionOrchestrator
    VoiceTranscriptionOrchestrator --> FileDownloader
    VoiceTranscriptionOrchestrator --> TranscriptionProvider
    VoiceTranscriptionOrchestrator --> SummaryOrchestrator
```

### Sequence Diagram

```mermaid
sequenceDiagram
    participant User
    participant Bot as TelegramBotController
    participant Orch as VoiceTranscriptionOrchestrator
    participant Down as FileDownloader
    participant Whisper as TranscriptionProvider
    participant Sum as SummaryOrchestrator
    
    User->>Bot: Отправляет голосовое сообщение 🎤
    Bot->>User: "🎧 Слушаю голосовое..."
    Bot->>Bot: sendChatAction(Typing)
    Bot->>Orch: processVoice(fileId)
    Orch->>Down: download(fileId)
    Down-->>Orch: ByteArray
    Orch->>Whisper: transcribe(audioBytes)
    Whisper-->>Orch: transcribedText
    
    alt Текст < 50 символов
        Orch-->>Bot: ShortMessage(text)
        Bot->>User: "🗣 *Текст:* ..."
    else Текст >= 50 символов
        Orch->>Sum: summarizeText(transcribedText)
        Sum-->>Orch: Summary
        Orch-->>Bot: LongMessageWithSummary(text, summary)
        Bot->>User: "📄 Текст: ..."
        Bot->>User: Форматированное саммари
    end
```

## 3. Detailed Component Design

### 3.1. Infrastructure Layer (Работа с внешним миром)

#### Component A: TelegramFileDownloader

Отвечает только за получение байтов из Telegram. Никакой бизнес-логики.

**Signature:**
```kotlin
interface FileDownloader {
    suspend fun downloadFile(fileId: String): ByteArray
}
```

**Implementation Details:**
```kotlin
class TelegramFileDownloader(
    private val bot: TelegramBot,
    private val botToken: String,
    private val httpClient: HttpClient  // Ktor HTTP client (уже есть в зависимостях)
) : FileDownloader {
    
    override suspend fun downloadFile(fileId: String): ByteArray {
        // 1. Вызвать bot.getFile(fileId) -> получить filePath
        val fileResponse = bot.getFile(fileId)
        val telegramFile = fileResponse.first?.body()?.result
            ?: throw DownloadException("File metadata not available")
        
        val filePath = telegramFile.filePath
            ?: throw DownloadException("File path not found")
        
        // 2. Сформировать URL: https://api.telegram.org/file/bot<TOKEN>/<FILE_PATH>
        val downloadUrl = "https://api.telegram.org/file/bot$botToken/$filePath"
        
        // 3. Скачать байты асинхронно через Ktor HttpClient
        // ВАЖНО: Используем httpClient вместо URL.readBytes() для неблокирующей операции
        return try {
            httpClient.get(downloadUrl).body()  // Полностью асинхронно
        } catch (e: Exception) {
            throw DownloadException("Failed to download file", e)
        }
    }
}
```

**Critical Note on Async I/O:**
- ❌ **НЕ используй** `URL.readBytes()` - это блокирующая операция
- ✅ **Используй** Ktor `HttpClient` для асинхронного скачивания
- Альтернатива: оберни в `withContext(Dispatchers.IO)`, но HttpClient лучше

**Error Handling:**
- Если `filePath` null или скачивание упало — бросать `DownloadException`
- Включать оригинальное исключение как `cause` для отладки

**Dependencies:**
- Ktor HttpClient (уже есть в проекте для асинхронных HTTP запросов)
- Telegram Bot API client

#### Component B: OpenAiTranscriptionProvider

Обертка над библиотекой OpenAI Client. Скрывает сложность работы с Okio и FileSource.

**Signature:**
```kotlin
interface TranscriptionProvider {
    suspend fun transcribe(audioBytes: ByteArray): String
}
```

**Implementation Details:**
```kotlin
class OpenAiTranscriptionProvider(
    private val openAiClient: OpenAI
) : TranscriptionProvider {
    
    override suspend fun transcribe(audioBytes: ByteArray): String {
        // 1. Преобразовать ByteArray -> okio.Buffer
        val fileSource = FileSource(
            name = "voice.ogg",  // Важно для Whisper, чтобы понять формат
            source = audioBytes.inputStream().source().buffer()
        )
        
        // 2. Создать запрос к Whisper
        val request = TranscriptionRequest(
            audio = fileSource,
            model = ModelId("whisper-1"),
            language = "ru"
        )
        
        // 3. Вызвать openAi.transcription
        return try {
            val transcription = openAiClient.transcription(request)
            transcription.text
        } catch (e: Exception) {
            throw TranscriptionException("Whisper transcription failed", e)
        }
    }
}
```

**Dependencies:**
- OpenAI Kotlin Client (`com.aallam.openai`)
- Okio library (`okio.source`, `okio.buffer`)

### 3.2. Domain Layer (Бизнес-логика)

#### Component C: VoiceProcessingOrchestrator

Главный "мозг" фичи. Он решает, что делать с текстом.

**Result Data Class:**
```kotlin
sealed class VoiceProcessingResult {
    data class ShortMessage(val text: String) : VoiceProcessingResult()
    data class LongMessageWithSummary(
        val rawText: String,
        val summary: Summary
    ) : VoiceProcessingResult()
}
```

**Interface:**
```kotlin
interface VoiceTranscriptionOrchestrator {
    suspend fun processVoice(fileId: String): VoiceProcessingResult
}
```

**Implementation:**
```kotlin
class VoiceTranscriptionOrchestratorImpl(
    private val fileDownloader: FileDownloader,
    private val transcriptionProvider: TranscriptionProvider,
    private val summaryOrchestrator: SummaryOrchestrator,
    private val shortTextThreshold: Int = 50
) : VoiceTranscriptionOrchestrator {
    
    override suspend fun processVoice(fileId: String): VoiceProcessingResult {
        // 1. Скачиваем файл
        val audioBytes = fileDownloader.downloadFile(fileId)
        
        // 2. Транскрибируем
        val transcribedText = transcriptionProvider.transcribe(audioBytes)
        
        // 3. Decision Point (The "50 chars" Rule)
        return if (transcribedText.length < shortTextThreshold) {
            // Короткий текст - возвращаем как есть
            VoiceProcessingResult.ShortMessage(transcribedText)
        } else {
            // Длинный текст - вызываем суммаризатор
            val summary = summaryOrchestrator.summarizeText(transcribedText)
            VoiceProcessingResult.LongMessageWithSummary(transcribedText, summary)
        }
    }
}
```

**Logic Flow:**
1. Вызывает `FileDownloader.download()`
2. Вызывает `TranscriptionProvider.transcribe()`
3. **Decision Point (The "50 chars" Rule):**
   - IF `text.length < 50`: Возвращает результат типа `ShortMessage` (без саммари)
   - ELSE: Вызывает существующий сервис `SummaryOrchestrator` и возвращает `LongMessageWithSummary`

### 3.3. Presentation Layer (Telegram Handlers)

Это то место, где мы подключаем логику к боту. Код должен быть минимальным.

**Implementation:**
```kotlin
fun TelegramBotController.setupVoiceHandlers(
    orchestrator: VoiceTranscriptionOrchestrator
) {
    // Обработчик голосовых сообщений
    voice {
        val chatId = ChatId.fromId(message.chat.id)
        val fileId = message.voice?.fileId ?: return@voice
        
        handleVoiceMessage(chatId, fileId, orchestrator)
    }
    
    // Обработчик аудиофайлов (та же логика)
    audio {
        val chatId = ChatId.fromId(message.chat.id)
        val fileId = message.audio?.fileId ?: return@audio
        
        handleVoiceMessage(chatId, fileId, orchestrator)
    }
}

private suspend fun TelegramBotController.handleVoiceMessage(
    chatId: ChatId,
    fileId: String,
    orchestrator: VoiceTranscriptionOrchestrator
) {
    try {
        // 1. UI Feedback
        bot.sendChatAction(chatId, ChatAction.Typing)
        bot.sendMessage(chatId, "🎧 Слушаю...")
        
        // 2. Call Domain
        val result = orchestrator.processVoice(fileId)
        
        // 3. Render Result
        when (result) {
            is VoiceProcessingResult.ShortMessage -> {
                bot.sendMessage(
                    chatId,
                    "🗣 *Текст:* ${result.text}",
                    parseMode = ParseMode.MARKDOWN
                )
            }
            is VoiceProcessingResult.LongMessageWithSummary -> {
                bot.sendMessage(chatId, "📄 Текст распознан. Анализирую...")
                bot.sendMessage(chatId, "📝 *Текст:* ${result.rawText}", parseMode = ParseMode.MARKDOWN)
                // Используем существующий formatter для саммари
                sendFormattedSummary(chatId, result.summary)
            }
        }
    } catch (e: Exception) {
        handleError(chatId, e)
    }
}

private suspend fun TelegramBotController.handleError(
    chatId: ChatId,
    exception: Exception
) {
    logger.error("Voice message processing failed", exception)
    
    val userMessage = when (exception) {
        is FileSizeLimitExceededException -> "❌ Файл слишком большой (лимит 20 МБ)."
        is DownloadException -> "❌ Не удалось скачать файл с серверов Telegram."
        is TranscriptionException -> "❌ OpenAI не смог распознать речь."
        else -> "❌ Произошла ошибка. Попробуйте позже."
    }
    
    bot.sendMessage(chatId, userMessage)
}
```

## 4. Error Handling Strategy

Мы должны перехватывать ошибки на уровне Orchestrator или Controller и мапить их в понятные сообщения.

### Exception Hierarchy

```kotlin
sealed class VoiceTranscriptionException(message: String, cause: Throwable? = null) 
    : Exception(message, cause)

class DownloadException(message: String, cause: Throwable? = null) 
    : VoiceTranscriptionException(message, cause)

class TranscriptionException(message: String, cause: Throwable? = null) 
    : VoiceTranscriptionException(message, cause)

class FileSizeLimitExceededException(message: String, cause: Throwable? = null) 
    : VoiceTranscriptionException(message, cause)
```

### Error Mapping Table

| Exception Type | User Message | Recovery |
|----------------|--------------|----------|
| FileSizeLimitExceededException | "❌ Файл слишком большой (лимит 20 МБ)." | User sends smaller file |
| DownloadException | "❌ Не удалось скачать файл с серверов Telegram." | User retries |
| TranscriptionException | "❌ OpenAI не смог распознать речь." | User retries |
| Generic Exception | "❌ Произошла ошибка. Попробуйте позже." | User retries |

### Logging Strategy

**What to log:**
- All exceptions with full stack traces (ERROR level)
- Start/completion of transcription (INFO level)
- External API calls (DEBUG level)

**What NOT to log:**
- User audio content (privacy)
- Transcribed text (privacy)
- Bot token (security)

## 5. Security & Configuration

### Token Management
- Токен бота передается в `FileDownloader` (так как он нужен для URL)
- Токен хранится в environment variables, не в коде

### Privacy
- Мы не логируем текст транскрипции и аудио-байты в консоль (только ID файлов)
- Аудио не сохраняется на диск
- Все обработка происходит в памяти

### Configuration

```kotlin
data class VoiceTranscriptionConfig(
    val shortTextThreshold: Int = 50,
    val maxFileSizeMb: Int = 20,
    val whisperModel: String = "whisper-1",
    val defaultLanguage: String = "ru"
)
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system—essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Download URL Formation

*For any* valid File_Path and bot token, the download URL SHALL be formatted as `https://api.telegram.org/file/bot{token}/{filePath}` with proper encoding.

**Validates: Requirements 2.3**

### Property 2: FileSource Creation from Bytes

*For any* non-empty byte array representing audio data, creating a FileSource SHALL succeed and produce a valid BufferedSource that can be read by the Whisper API.

**Validates: Requirements 3.5**

### Property 3: Text Length Threshold Logic

*For any* transcribed text, if the text length is less than 50 characters, the system SHALL return a ShortMessage result without invoking the summarizer; if the text length is 50 characters or more, the system SHALL invoke the summarizer and return a LongMessageWithSummary result.

**Validates: Requirements 5.1, 5.3, 6.1**

### Property 4: Exception Handling Completeness

*For any* exception thrown during voice message processing (file download, transcription, or summarization), the system SHALL catch the exception, log it with stack trace, and send an error message to the user containing the ❌ emoji and error description.

**Validates: Requirements 8.1, 8.3**

## Testing Strategy

### Dual Testing Approach

This feature will be tested using both unit tests and property-based tests:

**Unit Tests:**
- Verify specific examples and edge cases
- Test integration points between components
- Validate error handling for known failure scenarios
- Test UI formatting and message sending

**Property-Based Tests:**
- Verify universal properties across all inputs
- Test with randomized data (file paths, text lengths, byte arrays)
- Ensure correctness properties hold for 100+ iterations
- Catch edge cases that manual testing might miss

Both approaches are complementary and necessary for comprehensive coverage.

### Property-Based Testing Configuration

**Framework:** Kotest Property Testing (Kotlin)

**Configuration:**
- Minimum 100 iterations per property test
- Each test tagged with feature name and property number
- Tag format: `Feature: voice-transcription, Property {N}: {property_text}`

**Example:**
```kotlin
class VoiceTranscriptionPropertyTest : StringSpec({
    "Feature: voice-transcription, Property 3: Text Length Threshold Logic".config(
        iterations = 100
    ) {
        checkAll(Arb.string(0..200)) { text ->
            val result = orchestrator.determineResultType(text)
            
            if (text.length < 50) {
                result shouldBe instanceOf<VoiceProcessingResult.ShortMessage>()
            } else {
                result shouldBe instanceOf<VoiceProcessingResult.LongMessageWithSummary>()
            }
        }
    }
})
```

### Unit Testing Strategy

**Components to test:**

1. **TelegramFileDownloader**
   - Test successful file download
   - Test handling of missing file metadata
   - Test URL formation with various file paths
   - Mock Telegram API responses

2. **OpenAiTranscriptionProvider**
   - Test successful transcription
   - Test handling of API errors
   - Test FileSource creation from bytes
   - Mock OpenAI client responses

3. **VoiceTranscriptionOrchestrator**
   - Test short text path (< 50 chars)
   - Test long text path (>= 50 chars)
   - Test error propagation
   - Mock dependencies (downloader, transcription provider, summarizer)

4. **TelegramBotController**
   - Test voice event handler registration
   - Test audio event handler registration
   - Test user feedback messages
   - Test error message formatting
   - Mock bot and orchestrator

## Почему такой дизайн лучше?

### Testability
Ты сможешь протестировать Orchestrator, подсунув ему фейковый Downloader, который возвращает массив байтов из тестового файла, а не лезет в интернет.

### Scalability
Если завтра ты захочешь сменить OpenAI Whisper на Google Speech-to-Text, ты перепишешь только `TranscriptionProvider`, не трогая остальной код.

### Maintainability
Четкое разделение ответственности:
- Infrastructure: работа с внешними API
- Domain: бизнес-логика и решения
- Presentation: UI и форматирование

### Performance
In-memory обработка быстрее, чем сохранение на диск и чтение обратно.

## Dependencies

### External Libraries

```kotlin
// build.gradle.kts
dependencies {
    // Existing dependencies
    implementation("com.aallam.openai:openai-client:3.x.x")
    implementation("io.ktor:ktor-client-okhttp:2.x.x")
    
    // New dependencies for voice transcription
    implementation("com.squareup.okio:okio:3.x.x")  // For FileSource
    
    // Testing
    testImplementation("io.kotest:kotest-runner-junit5:5.x.x")
    testImplementation("io.kotest:kotest-assertions-core:5.x.x")
    testImplementation("io.kotest:kotest-property:5.x.x")  // Property-based testing
    testImplementation("io.mockk:mockk:1.x.x")
}
```

### Dependency Injection

```kotlin
// AppModule.kt additions
fun Application.configureVoiceTranscription() {
    val config = VoiceTranscriptionConfig()
    
    // Используем существующий HttpClient из проекта
    val httpClient = HttpClient(OkHttp) {
        install(HttpTimeout) {
            requestTimeoutMillis = 30000  // 30 секунд для больших файлов
        }
    }
    
    val fileDownloader = TelegramFileDownloader(
        bot = telegramBot,
        botToken = environment.config.property("telegram.token").getString(),
        httpClient = httpClient
    )
    
    val transcriptionProvider = OpenAiTranscriptionProvider(openAiClient)
    
    val orchestrator = VoiceTranscriptionOrchestratorImpl(
        fileDownloader = fileDownloader,
        transcriptionProvider = transcriptionProvider,
        summaryOrchestrator = summaryOrchestrator,
        shortTextThreshold = config.shortTextThreshold
    )
    
    telegramBotController.setupVoiceHandlers(orchestrator)
}
```

## Future Enhancements

1. **Multi-language support**: Auto-detect language instead of hardcoding "ru"
2. **Audio duration check**: Reject very long audio files before transcription
3. **Caching**: Cache transcriptions for identical audio files
4. **Batch processing**: Process multiple voice messages in parallel
5. **Custom prompts**: Allow users to specify transcription prompts for better accuracy
