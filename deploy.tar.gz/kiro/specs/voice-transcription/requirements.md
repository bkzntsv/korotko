# Requirements Document

## Introduction

Система транскрибации голосовых сообщений расширяет существующий Telegram-бот возможностью обработки голосовых сообщений и аудиофайлов. Пользователи смогут отправлять голосовые сообщения, которые будут автоматически преобразованы в текст с помощью OpenAI Whisper, а затем проанализированы существующим суммаризатором.

## Glossary

- **Bot**: Telegram-бот, обрабатывающий входящие сообщения
- **Whisper**: Модель OpenAI для транскрибации аудио в текст (whisper-1)
- **Voice_Message**: Голосовое сообщение, записанное через микрофон в Telegram
- **Audio_File**: Загруженный аудиофайл (mp3, ogg и другие форматы)
- **Transcription**: Процесс преобразования аудио в текст
- **File_ID**: Уникальный идентификатор файла в Telegram API
- **File_Path**: Путь к файлу на серверах Telegram
- **Summarizer**: Существующий компонент для анализа и суммаризации текста
- **Download_URL**: URL для скачивания файла с серверов Telegram

## Requirements

### Requirement 1: Обработка голосовых сообщений

**User Story:** Как пользователь, я хочу отправлять голосовые сообщения боту, чтобы получить их текстовую расшифровку и анализ содержания.

#### Acceptance Criteria

1. WHEN пользователь отправляет голосовое сообщение, THEN THE Bot SHALL распознать событие Voice и начать обработку
2. WHEN Bot получает голосовое сообщение, THEN THE Bot SHALL отправить пользователю уведомление о начале обработки
3. WHEN Bot обрабатывает голосовое сообщение, THEN THE Bot SHALL показать статус "typing" в интерфейсе чата
4. WHEN голосовое сообщение не содержит File_ID, THEN THE Bot SHALL прервать обработку без ошибки

### Requirement 2: Скачивание аудиофайлов

**User Story:** Как система, я хочу получать аудиофайлы с серверов Telegram, чтобы передать их на транскрибацию.

#### Acceptance Criteria

1. WHEN Bot получает File_ID, THEN THE Bot SHALL запросить метаданные файла через Telegram API
2. WHEN Telegram API возвращает метаданные, THEN THE Bot SHALL извлечь File_Path из ответа
3. WHEN Bot имеет File_Path, THEN THE Bot SHALL сформировать Download_URL используя токен бота и File_Path
4. WHEN Bot формирует Download_URL, THEN THE Bot SHALL скачать файл как массив байтов
5. IF метаданные файла недоступны, THEN THE Bot SHALL отправить пользователю сообщение об ошибке

### Requirement 3: Транскрибация аудио (Audio Processing)

**User Story:** Как пользователь, я хочу отправить голосовое сообщение, чтобы получить выжимку, не набирая текст вручную.

#### Acceptance Criteria

1. WHEN пользователь отправляет голосовое сообщение, THEN THE Bot SHALL скачать аудиофайл через Telegram API
2. WHEN аудиофайл получен, THEN THE Bot SHALL отправить его в модель Whisper для транскрибации
3. WHEN транскрибация успешна, THEN THE Bot SHALL обработать полученный текст через существующий AI Summarization pipeline
4. WHEN голосовое сообщение короче 5 секунд, THEN THE Bot SHALL вернуть только транскрибированный текст без суммаризации
5. WHEN Bot получает массив байтов аудиофайла, THEN THE Bot SHALL создать FileSource из байтов в памяти
6. WHEN Bot создает запрос к Whisper, THEN THE Bot SHALL использовать модель whisper-1
7. WHEN Bot отправляет запрос к Whisper, THEN THE Bot SHALL указать язык "ru" для русскоязычных сообщений
8. WHEN Whisper возвращает результат, THEN THE Bot SHALL извлечь текстовую расшифровку
9. IF транскрибация завершается ошибкой, THEN THE Bot SHALL обработать исключение и уведомить пользователя

### Requirement 4: Структурированные данные (Structured Data)

**User Story:** Как система, я хочу получать данные от AI в строгом формате, чтобы программно обрабатывать ошибки и форматирование.

#### Acceptance Criteria

1. WHEN валидный текст предоставлен, THEN THE Summarizer SHALL запросить данные в формате JSON (Schema: title, mainIdea, keyPoints, sentiment)
2. WHEN ответ AI не может быть распарсен как JSON, THEN THE Summarizer SHALL повторить запрос или вернуть ошибку парсинга
3. WHEN генерируется саммари, THEN THE Summarizer SHALL использовать модель gpt-4o-mini с system prompt, требующим вывод на русском языке
4. WHEN контент определен как "Clickbait" (высокий clickbait score в JSON), THEN THE Bot SHALL добавить предупреждающее эмодзи к ответу

### Requirement 5: Обработка коротких текстов

**User Story:** Как пользователь, я хочу получать простую текстовую расшифровку для коротких сообщений, чтобы не тратить время на анализ простых фраз.

#### Acceptance Criteria

1. WHEN длина распознанного текста меньше 50 символов, THEN THE Bot SHALL отправить только текстовую расшифровку
2. WHEN Bot отправляет короткий текст, THEN THE Bot SHALL использовать эмодзи 🗣 и форматирование Markdown
3. WHEN длина распознанного текста меньше 50 символов, THEN THE Bot SHALL пропустить этап суммаризации

### Requirement 6: Интеграция с суммаризатором

**User Story:** Как пользователь, я хочу получать структурированный анализ длинных голосовых сообщений, чтобы быстро понять основную суть.

#### Acceptance Criteria

1. WHEN длина распознанного текста 50 символов или больше, THEN THE Bot SHALL передать текст в Summarizer
2. WHEN Bot передает текст в Summarizer, THEN THE Bot SHALL отправить пользователю уведомление о начале анализа
3. WHEN Summarizer возвращает результат, THEN THE Bot SHALL отправить форматированное саммари пользователю
4. WHEN Bot вызывает Summarizer, THEN THE Bot SHALL использовать существующую функцию summarizeText

### Requirement 7: Обработка аудиофайлов

**User Story:** Как пользователь, я хочу отправлять загруженные аудиофайлы боту, чтобы получить их расшифровку и анализ.

#### Acceptance Criteria

1. WHEN пользователь отправляет аудиофайл, THEN THE Bot SHALL распознать событие Audio и начать обработку
2. WHEN Bot обрабатывает аудиофайл, THEN THE Bot SHALL использовать ту же логику, что и для голосовых сообщений
3. WHEN Bot получает Audio событие, THEN THE Bot SHALL извлечь File_ID из message.audio

### Requirement 8: Обработка ошибок

**User Story:** Как пользователь, я хочу получать понятные сообщения об ошибках, чтобы понимать, что пошло не так.

#### Acceptance Criteria

1. IF любой этап обработки завершается исключением, THEN THE Bot SHALL перехватить исключение
2. WHEN Bot перехватывает исключение, THEN THE Bot SHALL вывести stack trace в консоль для отладки
3. WHEN Bot перехватывает исключение, THEN THE Bot SHALL отправить пользователю сообщение с описанием ошибки
4. WHEN Bot отправляет сообщение об ошибке, THEN THE Bot SHALL использовать эмодзи ❌ и текст ошибки

### Requirement 9: Ограничения размера файлов

**User Story:** Как система, я хочу корректно обрабатывать ограничения Telegram API, чтобы избежать ошибок при работе с большими файлами.

#### Acceptance Criteria

1. WHEN размер файла превышает 20 МБ, THEN THE Bot SHALL получить ошибку от Telegram API
2. WHEN Bot получает ошибку о размере файла, THEN THE Bot SHALL обработать её как обычное исключение
3. THE Bot SHALL поддерживать файлы размером до 20 МБ

### Requirement 10: Форматы аудиофайлов

**User Story:** Как система, я хочу поддерживать различные аудиоформаты, чтобы обрабатывать разные типы сообщений.

#### Acceptance Criteria

1. WHEN Bot получает голосовое сообщение, THEN THE Bot SHALL обрабатывать формат .ogg (Opus)
2. WHEN Bot получает аудиофайл, THEN THE Bot SHALL поддерживать форматы mp3, ogg и другие
3. WHEN Bot создает FileSource, THEN THE Bot SHALL использовать имя файла "voice_message.ogg" для голосовых сообщений

### Requirement 11: Зависимости

**User Story:** Как разработчик, я хочу иметь все необходимые библиотеки, чтобы реализовать функциональность транскрибации.

#### Acceptance Criteria

1. THE Bot SHALL использовать библиотеку Okio для работы с потоками файлов
2. THE Bot SHALL использовать OpenAI Client для взаимодействия с Whisper API
3. THE Bot SHALL использовать Telegram Bot API для получения файлов
4. THE Bot SHALL импортировать okio.source и okio.buffer для создания FileSource

## Non-Functional Requirements

### NFR 1: Deployment & Infrastructure

**User Story:** Как DevOps инженер, я хочу иметь контейнеризованное приложение, чтобы упростить развертывание и масштабирование.

#### Acceptance Criteria

1. THE Application SHALL быть контейнеризовано с использованием Docker
2. THE Docker_Image SHALL быть построен с использованием multi-stage build процесса для минимизации размера образа

### NFR 2: Performance

**User Story:** Как система, я хочу обрабатывать множественные запросы эффективно, чтобы обеспечить хорошую производительность для пользователей.

#### Acceptance Criteria

1. THE System SHALL обрабатывать конкурентные запросы от минимум 10 пользователей без сбоев
2. THE Bot_Response_Time (исключая AI latency) SHALL быть менее 500ms

### NFR 3: Observability

**User Story:** Как разработчик, я хочу иметь логирование ключевых событий, чтобы отслеживать работу системы и диагностировать проблемы.

#### Acceptance Criteria

1. THE Application SHALL логировать все ключевые события (start, error, external API call) в stdout в структурированном формате (SLF4J)
2. THE Application SHALL NOT логировать пользовательские данные (текст статей, голосовые сообщения) для сохранения приватности
