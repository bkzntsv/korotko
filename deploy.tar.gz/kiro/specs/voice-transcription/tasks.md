# Implementation Plan: Voice Transcription

## Overview

Реализация функциональности транскрибации голосовых сообщений следует архитектуре из design.md с четким разделением на Infrastructure, Domain и Presentation слои. Все компоненты будут интегрированы через Dependency Injection.

## Tasks

- [ ] 1. Создать exception hierarchy и data models
  - Создать sealed class `VoiceTranscriptionException` с подклассами: `DownloadException`, `TranscriptionException`, `FileSizeLimitExceededException`
  - Создать sealed class `VoiceProcessingResult` с вариантами: `ShortMessage`, `LongMessageWithSummary`
  - Создать data class `VoiceTranscriptionConfig` с параметрами конфигурации
  - _Requirements: 7.1, 8.1_

- [ ] 2. Реализовать Infrastructure Layer: FileDownloader
  - [ ] 2.1 Создать interface `FileDownloader` с методом `downloadFile(fileId: String): ByteArray`
    - Определить сигнатуру интерфейса
    - _Requirements: 2.1, 2.2_

  - [ ] 2.2 Реализовать `TelegramFileDownloader`
    - Реализовать получение метаданных файла через `bot.getFile(fileId)` (возвращает объект File с file_path)
    - Реализовать формирование download URL: `https://api.telegram.org/file/bot<token>/<file_path>`
    - Реализовать асинхронное скачивание через Ktor HttpClient
    - Добавить проверку размера файла из метаданных (лимит 20 МБ для Telegram, 25 МБ для Whisper)
    - Обработать ошибки и бросать `DownloadException` или `FileSizeLimitExceededException`
    - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5, 9.1, 9.2_

  - [ ]* 2.3 Написать property test для URL формирования
    - **Property 1: Download URL Formation**
    - **Validates: Requirements 2.3**

  - [ ]* 2.4 Написать unit tests для TelegramFileDownloader
    - Тест успешного скачивания файла
    - Тест обработки отсутствующих метаданных
    - Тест обработки ошибок скачивания
    - _Requirements: 2.1, 2.2, 2.4, 2.5_

- [ ] 3. Реализовать Infrastructure Layer: TranscriptionProvider
  - [ ] 3.1 Создать interface `TranscriptionProvider` с методом `transcribe(audioBytes: ByteArray): String`
    - Определить сигнатуру интерфейса
    - _Requirements: 3.2, 3.6_

  - [ ] 3.2 Реализовать `OpenAiTranscriptionProvider`
    - Реализовать создание FileSource из ByteArray с использованием Okio
    - Использовать имя файла "voice.ogg" (Telegram использует .ogg с кодеком OPUS, поддерживается Whisper)
    - Реализовать формирование TranscriptionRequest с моделью whisper-1 и языком "ru"
    - Добавить опциональный prompt для улучшения распознавания IT-терминов: "Голосовое сообщение из Telegram. Возможно содержит технические термины: Kotlin, Java, IT."
    - Реализовать вызов OpenAI API и извлечение текста
    - Обработать ошибки и бросать `TranscriptionException`
    - _Requirements: 3.5, 3.6, 3.7, 3.8, 3.9, 10.1_

  - [ ]* 3.3 Написать property test для FileSource создания
    - **Property 2: FileSource Creation from Bytes**
    - **Validates: Requirements 3.5**

  - [ ]* 3.4 Написать unit tests для OpenAiTranscriptionProvider
    - Тест успешной транскрибации
    - Тест создания FileSource с правильным именем файла
    - Тест использования правильной модели и языка
    - Тест обработки ошибок API
    - _Requirements: 3.5, 3.6, 3.7, 3.8, 3.9_

- [ ] 4. Checkpoint - Убедиться, что Infrastructure Layer работает
  - Ensure all tests pass, ask the user if questions arise.

- [ ] 5. Реализовать Domain Layer: VoiceTranscriptionOrchestrator
  - [ ] 5.1 Создать interface `VoiceTranscriptionOrchestrator` с методом `processVoice(fileId: String): VoiceProcessingResult`
    - Определить сигнатуру интерфейса
    - _Requirements: 1.1, 3.1_

  - [ ] 5.2 Реализовать `VoiceTranscriptionOrchestratorImpl`
    - Реализовать вызов `fileDownloader.downloadFile()` (уже включает проверку размера файла)
    - Реализовать вызов `transcriptionProvider.transcribe()`
    - Реализовать логику threshold (50 символов) для определения типа результата
    - Для коротких текстов возвращать `ShortMessage`
    - Для длинных текстов вызывать `summaryOrchestrator.summarizeText()` и возвращать `LongMessageWithSummary`
    - _Requirements: 3.1, 3.2, 3.3, 5.1, 5.3, 6.1, 6.4_

  - [ ]* 5.3 Написать property test для text length threshold logic
    - **Property 3: Text Length Threshold Logic**
    - **Validates: Requirements 5.1, 5.3, 6.1**

  - [ ]* 5.4 Написать unit tests для VoiceTranscriptionOrchestrator
    - Тест обработки короткого текста (< 50 символов)
    - Тест обработки длинного текста (>= 50 символов)
    - Тест вызова summarizer для длинных текстов
    - Тест отсутствия вызова summarizer для коротких текстов
    - Тест пробрасывания исключений из dependencies
    - _Requirements: 5.1, 5.3, 6.1, 6.4_

- [ ] 6. Checkpoint - Убедиться, что Domain Layer работает
  - Ensure all tests pass, ask the user if questions arise.

- [ ] 7. Реализовать Presentation Layer: Telegram Bot Handlers
  - [ ] 7.1 Создать extension function `setupVoiceHandlers()` для TelegramBotController
    - Реализовать voice handler с извлечением fileId из `message.voice`
    - Реализовать audio handler с извлечением fileId из `message.audio`
    - Оба handler должны вызывать общую функцию `handleVoiceMessage()`
    - _Requirements: 1.1, 1.4, 7.1, 7.2, 7.3_

  - [ ] 7.2 Реализовать `handleVoiceMessage()` helper function
    - Отправить feedback сообщение "🎧 Слушаю..." пользователю
    - Показать typing indicator через `sendChatAction()`
    - Вызвать `orchestrator.processVoice(fileId)`
    - Для `ShortMessage` отправить текст с эмодзи 🗣 и Markdown форматированием
    - Для `LongMessageWithSummary` отправить уведомление "📄 Текст распознан. Анализирую...", затем текст и форматированное саммари
    - _Requirements: 1.2, 1.3, 5.2, 6.2, 6.3_

  - [ ] 7.3 Реализовать `handleError()` helper function
    - Логировать исключение с stack trace
    - Мапить типы исключений в user-friendly сообщения
    - Отправлять сообщение с эмодзи ❌ пользователю
    - _Requirements: 8.1, 8.2, 8.3, 8.4_

  - [ ]* 7.4 Написать property test для exception handling
    - **Property 4: Exception Handling Completeness**
    - **Validates: Requirements 8.1, 8.3**

  - [ ]* 7.5 Написать unit tests для Telegram handlers
    - Тест регистрации voice handler
    - Тест регистрации audio handler
    - Тест отправки feedback сообщений
    - Тест форматирования короткого текста
    - Тест форматирования длинного текста с саммари
    - Тест обработки каждого типа исключения
    - _Requirements: 1.1, 1.2, 1.3, 5.2, 6.2, 7.1, 7.2, 8.1, 8.3, 8.4_

- [ ] 8. Настроить Dependency Injection
  - [ ] 8.1 Добавить зависимости в build.gradle.kts
    - Убедиться, что Okio library присутствует
    - Добавить Kotest property testing для тестов
    - _Requirements: 11.1, 11.2_

  - [ ] 8.2 Создать `configureVoiceTranscription()` в AppModule
    - Создать HttpClient с timeout конфигурацией
    - Инициализировать TelegramFileDownloader с bot, token и httpClient
    - Инициализировать OpenAiTranscriptionProvider с openAiClient
    - Инициализировать VoiceTranscriptionOrchestratorImpl со всеми dependencies
    - Вызвать `setupVoiceHandlers()` на telegramBotController
    - _Requirements: 1.1, 11.1, 11.2, 11.3_

  - [ ] 8.3 Интегрировать `configureVoiceTranscription()` в Main.kt
    - Вызвать функцию при старте приложения
    - _Requirements: 1.1_

- [ ] 9. Final checkpoint - End-to-end тестирование
  - Ensure all tests pass, ask the user if questions arise.
  - Проверить работу с реальным ботом (manual testing)

## Notes

- Tasks marked with `*` are optional and can be skipped for faster MVP
- Each task references specific requirements for traceability
- Checkpoints ensure incremental validation
- Property tests validate universal correctness properties
- Unit tests validate specific examples and edge cases
- Все компоненты должны быть протестированы с mock dependencies перед интеграцией

### Technical Implementation Notes

1. **Telegram File Download (Task 2.2):**
   - `bot.getFile(fileId)` возвращает объект File с `file_path`, НЕ сам файл
   - Для скачивания нужен двухэтапный процесс: получить file_path → скачать по URL
   - URL формат: `https://api.telegram.org/file/bot<token>/<file_path>`

2. **File Size Limits (Task 2.2):**
   - Telegram Bot API: максимум 20 МБ
   - OpenAI Whisper: максимум 25 МБ
   - Проверять размер сразу после получения метаданных, до скачивания

3. **Audio Formats (Task 3.2):**
   - Telegram отправляет голосовые в формате .ogg (кодек OPUS)
   - Whisper поддерживает .ogg, .oga, .opus нативно
   - Конвертация через FFmpeg НЕ требуется

4. **Whisper Prompting (Task 3.2):**
   - Можно передать prompt для улучшения распознавания специфических терминов
   - Пример: "Голосовое сообщение из Telegram. Возможно содержит технические термины: Kotlin, Java, IT."
   - Это опциональная оптимизация, но может улучшить качество
