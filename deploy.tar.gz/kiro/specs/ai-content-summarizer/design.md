# Design Document: AI Content Summarizer Bot

## Overview

AI Content Summarizer Bot - это Telegram-бот на Kotlin, который извлекает контент из веб-статей и создает краткие выжимки через OpenAI API. Архитектура следует принципам Clean Architecture с четким разделением слоев: Presentation (Telegram Controller), Domain (Business Logic), и Infrastructure (External Services).

## Architecture

### High-Level Architecture

```mermaid
graph TB
    User[Telegram User] --> TelegramController
    TelegramController --> Orchestrator
    Orchestrator --> ContentExtractor
    Orchestrator --> AIProvider
    Orchestrator --> ResponseFormatter
    ContentExtractor --> WebSite[External Website]
    AIProvider --> OpenAI[OpenAI API]
    TelegramController --> User
```

### Layer Responsibilities

**Presentation Layer (Telegram Controller)**
- Обработка входящих сообщений и команд
- Валидация пользовательского ввода
- Отправка ответов и индикаторов статуса
- Обработка ошибок на уровне UI

**Domain Layer (Orchestrator)**
- Координация процесса обработки запроса
- Бизнес-логика (валидация, обработка результатов)
- Управление потоком данных между компонентами

**Infrastructure Layer**
- Content Extraction (Jsoup)
- AI Integration (OpenAI API через Ktor Client)
- Configuration Management (Environment Variables)

## Components and Interfaces

### 1. Telegram Controller

```kotlin
interface TelegramBot {
    suspend fun handleMessage(message: Message)
    suspend fun handleCommand(command: Command)
    suspend fun sendMessage(chatId: Long, text: String, parseMode: ParseMode)
    suspend fun sendTypingIndicator(chatId: Long)
}

class TelegramBotImpl(
    private val orchestrator: SummaryOrchestrator,
    private val token: String
) : TelegramBot {
    // Implementation
}
```

**Responsibilities:**
- Прием и парсинг Telegram updates
- Извлечение URL из текстовых сообщений (через message.entities предпочтительно, fallback на regex)
- Отправка typing indicator во время обработки
- Форматирование и отправка ответов

**URL Extraction Strategy:**
- Использовать `message.entities` от Telegram API (надежнее, так как Telegram уже распознал ссылки)
- Fallback на regex если entities отсутствуют
- Обрабатывать только первый валидный URL в сообщении

### 2. Summary Orchestrator

```kotlin
interface SummaryOrchestrator {
    suspend fun processSummaryRequest(url: String): Result<Summary>
}

class SummaryOrchestratorImpl(
    private val contentExtractor: ContentExtractor,
    private val aiProvider: AIProvider
) : SummaryOrchestrator {
    override suspend fun processSummaryRequest(url: String): Result<Summary> {
        // 1. Extract content
        // 2. Send to AI
        // 3. Return result
    }
}
```

**Responsibilities:**
- Координация процесса извлечения и суммаризации
- Обработка ошибок на каждом этапе
- Управление асинхронными операциями

### 3. Content Extractor

```kotlin
interface ContentExtractor {
    suspend fun extractContent(url: String): Result<ExtractedContent>
}

data class ExtractedContent(
    val text: String,
    val title: String?,
    val url: String,
    val wasTruncated: Boolean = false // Флаг для индикации обрезания
)

class ArticleExtractor : ContentExtractor {
    override suspend fun extractContent(url: String): Result<ExtractedContent> {
        // Jsoup implementation
        // Filter <p>, <h1>-<h3> tags
        // Remove navigation, ads, footers
    }
}
```

**Responsibilities:**
- HTTP запрос к веб-странице с realistic browser User-Agent
- Парсинг HTML через Jsoup или Readability4J
- Извлечение основного текста (параграфы и заголовки)
- Извлечение заголовка статьи
- Очистка от навигации, рекламы, футеров
- Валидация размера текста (минимум 200 символов)
- Обрезание длинных текстов (максимум 50000 символов)

**Extraction Strategy:**
- Рекомендуется использовать **Readability4J** (порт Mozilla Readability) поверх Jsoup
- Workflow: Ktor скачивает HTML → Readability4J обрабатывает HTML string или Jsoup Document
- Readability4J автоматически находит основной читаемый контент
- Fallback на Jsoup селекторы если Readability4J не справляется:
  - Использовать селекторы: `article`, `main`, `.content`
  - Извлекать теги: `p`, `h1`, `h2`, `h3`
  - Исключать: `nav`, `footer`, `aside`, `.ad`, `.advertisement`

### 4. AI Provider

```kotlin
interface AIProvider {
    suspend fun generateSummary(content: ExtractedContent): Result<Summary>
}

data class Summary(
    val mainIdea: String,
    val keyPoints: List<String>,
    val title: String?,
    val originalUrl: String
)

class OpenAIProvider(
    private val apiKey: String,
    private val httpClient: HttpClient
) : AIProvider {
    private val model = "gpt-4o-mini"
    
    override suspend fun generateSummary(content: ExtractedContent): Result<Summary> {
        // Call OpenAI API
        // Parse response
        // Return structured summary
    }
}
```

**Responsibilities:**
- Формирование запроса к OpenAI API
- Создание системного промпта для суммаризации
- Обработка ответа и маппинг в Summary DTO
- Обработка ошибок API (timeout, rate limits, etc.)

**System Prompt:**
```
Ты - помощник для создания кратких выжимок статей. 
Проанализируй текст и создай:
1. Одно предложение с главной идеей
2. 3-5 ключевых тезисов (каждый - одно предложение)

Если текст не на русском языке, переведи выжимку на русский.
Формат ответа: JSON с полями "mainIdea" (string) и "keyPoints" (array of strings).
```

**ВАЖНО:** Системный промпт должен явно содержать слово "JSON" для корректной работы JSON Mode в OpenAI API.

**OpenAI API Configuration:**
```kotlin
val request = ChatCompletionRequest(
    model = "gpt-4o-mini",
    messages = listOf(
        ChatMessage(role = "system", content = systemPrompt),
        ChatMessage(role = "user", content = content.text)
    ),
    responseFormat = ResponseFormat(type = "json_object"), // Гарантирует JSON ответ
    temperature = 0.7
)
```

Использование `response_format: { "type": "json_object" }` гарантирует, что модель вернет валидный JSON без лишнего текста.

### 5. Response Formatter

```kotlin
object ResponseFormatter {
    fun formatSummary(summary: Summary, wasTruncated: Boolean = false): String {
        // Format as Telegram Markdown
        // Include original URL and title
        // Structure: Main Idea + Key Points
        // Add truncation note if wasTruncated = true
    }
    
    fun formatError(error: SummarizerError): String {
        // User-friendly error messages
    }
}
```

**Responsibilities:**
- Форматирование Summary в Telegram Markdown
- Создание структурированного ответа
- Добавление пометки об обрезании текста при необходимости
- Форматирование сообщений об ошибках

**Output Format:**
```markdown
📄 **[Article Title]**

**Суть:** [Main Idea]

**Ключевые тезисы:**
• [Key Point 1]
• [Key Point 2]
• [Key Point 3]

⚠️ _Статья очень длинная, обработана частично_ (если wasTruncated = true)

🔗 [Оригинал]([URL])
```

### 6. Configuration

```kotlin
data class BotConfig(
    val telegramToken: String,
    val openAiApiKey: String,
    val userAgent: String = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
)

object ConfigLoader {
    fun loadFromEnv(): BotConfig {
        val telegramToken = System.getenv("TELEGRAM_BOT_TOKEN")
            ?: throw ConfigurationException("TELEGRAM_BOT_TOKEN not set")
        val openAiApiKey = System.getenv("OPENAI_API_KEY")
            ?: throw ConfigurationException("OPENAI_API_KEY not set")
        
        return BotConfig(telegramToken, openAiApiKey)
    }
}
```

## Data Models

### Domain Models

```kotlin
// Result wrapper for error handling
sealed class Result<out T> {
    data class Success<T>(val value: T) : Result<T>()
    data class Failure(val error: SummarizerError) : Result<Nothing>()
}

// Error types
sealed class SummarizerError {
    data class NetworkError(val message: String) : SummarizerError()
    data class ParsingError(val message: String) : SummarizerError()
    data class AIError(val message: String) : SummarizerError()
    data class ValidationError(val message: String) : SummarizerError()
    data class UnknownError(val throwable: Throwable) : SummarizerError()
}

// Telegram models
data class Message(
    val chatId: Long,
    val text: String,
    val userId: Long
)

data class Command(
    val chatId: Long,
    val command: String,
    val userId: Long
)

enum class ParseMode {
    MARKDOWN, HTML
}
```

### Data Flow

```
User Message (URL) 
  → TelegramController.handleMessage()
  → Orchestrator.processSummaryRequest(url)
    → ContentExtractor.extractContent(url) → ExtractedContent
    → AIProvider.generateSummary(content) → Summary
  → ResponseFormatter.formatSummary(summary) → String
  → TelegramController.sendMessage(chatId, formattedText)
→ User receives formatted summary
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system—essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*


### Property 1: URL Extraction Attempt

*For any* valid URL sent in a text message, the Bot should attempt to extract content from that URL.

**Validates: Requirements 1.1**

### Property 2: Invalid URL Error Handling

*For any* malformed or invalid URL, the Bot should return an error message to the user.

**Validates: Requirements 1.2**

### Property 3: First URL Processing

*For any* message containing multiple URLs, the Bot should process only the first valid URL and ignore the rest.

**Validates: Requirements 1.3**

### Property 4: Content Structure Preservation

*For any* HTML content with paragraphs and headings, the extracted text should preserve these structural elements and include the article title if available.

**Validates: Requirements 2.2, 2.5**

### Property 5: AI Summary Structure

*For any* valid text input to the AI Provider, the generated summary should contain exactly one main idea and between 3 to 5 key points.

**Validates: Requirements 3.1**

### Property 6: Russian Output Language

*For any* content in any language, the AI Provider should generate a summary in Russian.

**Validates: Requirements 4.1, 4.2**

### Property 7: Formatted Output Structure

*For any* summary, the formatted output should contain valid Telegram Markdown syntax, include the original URL and article title, and have distinct sections for main idea and key points.

**Validates: Requirements 5.1, 5.2, 5.3**

### Property 8: Typing Indicator

*For any* request being processed, the Bot should send a typing indicator to the user before sending the final response.

**Validates: Requirements 7.2**

### Property 9: Concurrent Request Processing

*For any* set of simultaneous requests from different users, the Bot should process them concurrently without one request blocking another.

**Validates: Requirements 7.3**

### Property 10: Realistic User-Agent Header

*For any* HTTP request made by the Content Extractor, the request should include a realistic browser User-Agent header.

**Validates: Requirements 8.3**

### Property 11: Unknown Command Response

*For any* unsupported command sent to the Bot, the response should suggest using the /help command.

**Validates: Requirements 9.3**

### Property 12: Content Length Validation

*For any* extracted content with less than 200 characters, the Content Extractor should return an error indicating insufficient content.

**Validates: Requirements 2.3**

### Property 13: Content Truncation with Notification

*For any* extracted content exceeding 50000 characters, the Content Extractor should truncate it to 50000 characters, and the formatted response should include a note indicating the article was processed partially.

**Validates: Requirements 2.4**

## Error Handling

### Error Types and Handling Strategy

**Network Errors (HTTP 4xx, 5xx)**
- 403 Forbidden: "Сайт защищен от автоматического извлечения контента"
- 404 Not Found: "Страница не найдена"
- 500+ Server Errors: "Сайт временно недоступен"
- Timeout: "Превышено время ожидания ответа от сайта"

**Parsing Errors**
- Invalid HTML: "Не удалось извлечь текст из страницы"
- Content too small (< 200 chars): "Текст статьи слишком короткий для создания выжимки (минимум 200 символов)"
- Content truncated (> 50000 chars): Автоматически обрезается до 50000 символов, пользователь получает выжимку с пометкой "Статья очень длинная, обработана частично"

**AI Errors**
- API Unavailable: "Сервис суммаризации временно недоступен, попробуйте позже"
- Rate Limit: "Превышен лимит запросов к AI, попробуйте через минуту"
- Invalid Response: "Не удалось создать выжимку, попробуйте другую статью"

**Validation Errors**
- Invalid URL: "Пожалуйста, отправьте корректную ссылку на статью"
- No URL Found: "Сообщение не содержит ссылку на статью"

**Unknown Errors**
- Log full stack trace
- Return to user: "Произошла ошибка при обработке запроса, попробуйте позже"

### Error Handling Flow

```kotlin
suspend fun processSummaryRequest(url: String): Result<Summary> {
    return try {
        val content = contentExtractor.extractContent(url)
            .getOrElse { error -> return Result.Failure(error) }
        
        val summary = aiProvider.generateSummary(content)
            .getOrElse { error -> return Result.Failure(error) }
        
        Result.Success(summary)
    } catch (e: Exception) {
        logger.error("Unexpected error processing $url", e)
        Result.Failure(SummarizerError.UnknownError(e))
    }
}
```

## Testing Strategy

### Dual Testing Approach

Проект будет использовать комбинацию unit-тестов и property-based тестов для обеспечения корректности:

**Unit Tests:**
- Проверка конкретных примеров и edge cases
- Тестирование интеграционных точек между компонентами
- Проверка обработки ошибок для специфических сценариев
- Примеры: /start команда возвращает welcome message, 404 ошибка возвращает правильное сообщение

**Property-Based Tests:**
- Проверка универсальных свойств на множестве сгенерированных входных данных
- Валидация correctness properties из секции выше
- Минимум 100 итераций на каждый property test
- Каждый тест должен быть помечен комментарием: `// Feature: ai-content-summarizer, Property N: [property text]`

### Property-Based Testing Framework

Для Kotlin будем использовать **Kotest Property Testing** (kotest-property):

```kotlin
dependencies {
    // Kotlin
    implementation("org.jetbrains.kotlin:kotlin-stdlib")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.7.3")
    
    // Telegram Bot
    implementation("io.github.kotlin-telegram-bot.kotlin-telegram-bot:telegram:6.1.0")
    
    // HTTP Client
    implementation("io.ktor:ktor-client-core:2.3.7")
    implementation("io.ktor:ktor-client-cio:2.3.7")
    implementation("io.ktor:ktor-client-content-negotiation:2.3.7")
    implementation("io.ktor:ktor-serialization-kotlinx-json:2.3.7")
    
    // HTML Parsing
    implementation("org.jsoup:jsoup:1.17.2")
    implementation("net.dankito.readability4j:readability4j:1.0.8") // Mozilla Readability port
    
    // Dependency Injection
    implementation("io.insert-koin:koin-core:3.5.3")
    
    // Logging
    implementation("ch.qos.logback:logback-classic:1.4.14")
    implementation("io.github.microutils:kotlin-logging-jvm:3.0.5")
    
    // Testing
    testImplementation("io.kotest:kotest-runner-junit5:5.8.0")
    testImplementation("io.kotest:kotest-assertions-core:5.8.0")
    testImplementation("io.kotest:kotest-property:5.8.0")
    testImplementation("io.mockk:mockk:1.13.9")
    testImplementation("io.ktor:ktor-client-mock:2.3.7") // Ktor MockEngine
    testImplementation("com.squareup.okhttp3:mockwebserver:4.12.0") // Альтернатива для HTTP моков
}
```

### Test Configuration

```kotlin
// Minimum 100 iterations per property test
PropertyTesting.defaultIterationCount = 100

// Example property test structure
class SummaryPropertiesTest : StringSpec({
    "Property 5: AI Summary Structure" {
        // Feature: ai-content-summarizer, Property 5: AI Summary Structure
        checkAll<String>(100) { text ->
            val summary = aiProvider.generateSummary(ExtractedContent(text, null, ""))
            summary.shouldBeSuccess()
            summary.value.keyPoints.size shouldBeInRange 3..5
            summary.value.mainIdea.shouldNotBeEmpty()
        }
    }
})
```

### Test Coverage Goals

**Unit Tests:**
- Command handlers (/start, /help, unknown commands)
- Error message formatting
- Configuration loading (with/without env vars)
- Response formatter output structure
- Specific HTTP error codes (403, 404, 500)

**Property Tests:**
- URL extraction and processing (Properties 1-3)
- Content structure preservation (Property 4)
- AI summary structure (Property 5)
- Russian output language (Property 6)
- Formatted output structure (Property 7)
- Typing indicator (Property 8)
- Concurrent processing (Property 9)
- User-Agent header (Property 10)
- Unknown command response (Property 11)

### Testing Dependencies and Mocking

**Mocking Strategy:**
- Mock external HTTP calls для Content Extractor тестов
- Mock OpenAI API для AI Provider тестов
- Use MockK library для Kotlin mocking

**Test Doubles:**
```kotlin
class MockContentExtractor : ContentExtractor {
    override suspend fun extractContent(url: String): Result<ExtractedContent> {
        return Result.Success(ExtractedContent("Test content", "Test Title", url))
    }
}

class MockAIProvider : AIProvider {
    override suspend fun generateSummary(content: ExtractedContent): Result<Summary> {
        return Result.Success(Summary(
            mainIdea = "Test main idea",
            keyPoints = listOf("Point 1", "Point 2", "Point 3"),
            title = content.title,
            originalUrl = content.url
        ))
    }
}
```

**HTTP Mocking для тестов:**
- Использовать **Ktor MockEngine** для мокирования HTTP запросов в тестах
- Альтернатива: **MockWebServer** от OkHttp для более сложных сценариев
- Это позволит тестам работать в CI/CD без реальных сетевых запросов

```kotlin
// Пример с Ktor MockEngine
val mockEngine = MockEngine { request ->
    respond(
        content = """{"mainIdea": "Test", "keyPoints": ["Point 1", "Point 2", "Point 3"]}""",
        status = HttpStatusCode.OK,
        headers = headersOf(HttpHeaders.ContentType, "application/json")
    )
}

val testClient = HttpClient(mockEngine) {
    install(ContentNegotiation) { json() }
}
```

## Dependency Injection

Используем **Koin** для управления зависимостями:

```kotlin
val appModule = module {
    // Configuration
    single { ConfigLoader.loadFromEnv() }
    
    // HTTP Client
    single {
        HttpClient(CIO) {
            install(ContentNegotiation) {
                json()
            }
            install(HttpTimeout) {
                requestTimeoutMillis = 30000
            }
        }
    }
    
    // Infrastructure
    single<ContentExtractor> { ArticleExtractor(get()) }
    single<AIProvider> { OpenAIProvider(get<BotConfig>().openAiApiKey, get()) }
    
    // Domain
    single<SummaryOrchestrator> { SummaryOrchestratorImpl(get(), get()) }
    
    // Presentation
    single<TelegramBot> { TelegramBotImpl(get(), get<BotConfig>().telegramToken) }
}

fun main() {
    startKoin {
        modules(appModule)
    }
    
    val bot = get<TelegramBot>()
    bot.start()
}
```

## Deployment and Configuration

### Environment Variables

```bash
# Required
TELEGRAM_BOT_TOKEN=your_telegram_bot_token
OPENAI_API_KEY=your_openai_api_key

# Optional
USER_AGENT="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
LOG_LEVEL=INFO
MAX_CONTENT_LENGTH=50000
MIN_CONTENT_LENGTH=200
```

### Build and Run

```bash
# Build
./gradlew build

# Create fat JAR
./gradlew shadowJar

# Run
java -jar build/libs/ai-content-summarizer-all.jar

# Or via Gradle
./gradlew run
```

### CI/CD Pipeline

**GitHub Actions** для автоматизации тестирования и сборки:

```yaml
# .github/workflows/ci.yml
name: CI

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Set up JDK 17
        uses: actions/setup-java@v3
        with:
          java-version: '17'
          distribution: 'temurin'
      
      - name: Run Unit Tests
        run: ./gradlew test
      
      - name: Run Property-Based Tests
        run: ./gradlew test --tests "*PropertiesTest"
      
      - name: Build JAR
        run: ./gradlew shadowJar
      
      - name: Upload Artifact
        uses: actions/upload-artifact@v3
        with:
          name: ai-content-summarizer-jar
          path: build/libs/*-all.jar
```

**Автоматические проверки:**
- Запуск всех unit и property тестов при каждом push
- Сборка fat JAR для проверки успешной компиляции
- Сохранение артефактов для деплоя

**Важно для CI/CD:**
- Тесты, требующие OpenAI API и внешних сайтов, должны использовать HTTP моки
- Рекомендуемые инструменты: **Ktor MockEngine** или **MockWebServer** от OkHttp
- Без API ключей в GitHub Secrets тесты с реальными запросами упадут
- Использовать test doubles (MockContentExtractor, MockAIProvider) для integration тестов в CI

### Logging

Используем **Logback** для логирования:

```kotlin
private val logger = LoggerFactory.getLogger(this::class.java)

// Log levels
logger.debug("Processing URL: $url")
logger.info("Summary generated for $url")
logger.warn("Rate limit approaching for user $userId")
logger.error("Failed to extract content from $url", exception)
```

## Performance Considerations

**Timeouts:**
- HTTP requests: 30 seconds
- OpenAI API: 60 seconds
- Overall request processing: 90 seconds

**Concurrency:**
- Используем Kotlin Coroutines для асинхронной обработки
- Каждый запрос обрабатывается в отдельной корутине
- Dispatcher: Dispatchers.IO для I/O операций

**Resource Management:**
- HTTP Client: один shared instance с connection pooling
- Graceful shutdown: 
  - Использовать `Runtime.getRuntime().addShutdownHook`
  - Закрыть HttpClient через `.close()`
  - Остановить Telegram Bot
  - Завершить активные корутины
  - Логировать успешное завершение

## Future Extensibility

Архитектура позволяет легко добавить:

1. **Новые источники контента:**
   - Создать новую реализацию `ContentExtractor`
   - Например: `YouTubeExtractor`, `PDFExtractor`
   - Использовать Strategy Pattern для выбора экстрактора по типу URL

2. **Альтернативные AI провайдеры:**
   - Создать новую реализацию `AIProvider`
   - Например: `AnthropicProvider`, `LocalLLMProvider`

3. **Дополнительные форматы вывода:**
   - Расширить `ResponseFormatter`
   - Добавить HTML, Plain Text форматы

4. **Персистентность:**
   - Добавить `CacheRepository` интерфейс
   - Реализации: `InMemoryCache`, `RedisCache`, `DatabaseCache`
