# Requirements Document

## Introduction

AI Content Summarizer Bot - это Telegram-бот, который принимает URL веб-статей, извлекает основной контент, создает краткую выжимку через OpenAI API и возвращает результат пользователю на русском языке в формате Markdown.

## Glossary

- **Bot**: Telegram-бот, обрабатывающий сообщения пользователей
- **Content_Extractor**: Компонент для извлечения текста из веб-страниц
- **AI_Provider**: Клиент для взаимодействия с OpenAI API
- **Orchestrator**: Сервисный слой, координирующий процесс обработки
- **Summary**: Краткая выжимка текста (суть + 3-5 ключевых тезисов)
- **User**: Пользователь Telegram, отправляющий запросы боту

## Requirements

### Requirement 1: URL Processing

**User Story:** Как пользователь, я хочу отправить боту ссылку на статью, чтобы получить краткую выжимку её содержания.

#### Acceptance Criteria

1. WHEN a User sends a text message containing a URL, THE Bot SHALL extract the content from the web page
2. WHEN a URL is invalid or malformed, THE Bot SHALL notify the User with an error message
3. WHEN multiple URLs are sent in one message, THE Bot SHALL process only the first valid URL

### Requirement 2: Content Extraction

**User Story:** Как система, я хочу извлекать только основной текст статьи, чтобы передать в AI релевантный контент без шума.

#### Acceptance Criteria

1. WHEN extracting content, THE Content_Extractor SHALL remove navigation elements, advertisements, and footers
2. WHEN extracting content, THE Content_Extractor SHALL preserve paragraph structure and headings
3. WHEN extracted text is less than 200 characters, THE Content_Extractor SHALL return an error indicating insufficient content
4. WHEN extracted text exceeds 50000 characters, THE Content_Extractor SHALL truncate it to the first 50000 characters
5. WHEN a website blocks scraping (403 Forbidden), THE Content_Extractor SHALL return an error with appropriate message
6. WHEN extracting content, THE Content_Extractor SHALL include the article title if available

### Requirement 3: AI Summarization

**User Story:** Как пользователь, я хочу получить краткую выжимку статьи, чтобы быстро понять её суть без чтения полного текста.

#### Acceptance Criteria

1. WHEN valid text is provided, THE AI_Provider SHALL generate a summary containing the main idea and 3-5 key points
2. WHEN the AI API is unavailable, THE AI_Provider SHALL return an error after timeout
3. WHEN the AI API returns an error, THE AI_Provider SHALL propagate the error with details
4. WHEN generating a summary, THE AI_Provider SHALL use GPT-4o-mini model

### Requirement 4: Multilingual Support

**User Story:** Как пользователь, я хочу получать выжимки на русском языке, даже если оригинальная статья на другом языке.

#### Acceptance Criteria

1. WHEN the original content is in a non-Russian language, THE AI_Provider SHALL translate the summary to Russian
2. WHEN the original content is in Russian, THE AI_Provider SHALL generate the summary in Russian without translation
3. WHEN language detection fails, THE AI_Provider SHALL default to generating a Russian summary

### Requirement 5: Response Formatting

**User Story:** Как пользователь, я хочу получать форматированный ответ, чтобы легко читать выжимку в Telegram.

#### Acceptance Criteria

1. WHEN sending a summary to User, THE Bot SHALL format it using Telegram Markdown
2. WHEN formatting a summary, THE Bot SHALL include the original URL and article title as references
3. WHEN formatting a summary, THE Bot SHALL structure it with clear sections (main idea and key points)

### Requirement 6: Error Handling

**User Story:** Как пользователь, я хочу получать понятные сообщения об ошибках, чтобы знать, что пошло не так.

#### Acceptance Criteria

1. WHEN a website is unavailable (404, 500), THE Bot SHALL notify the User that the page cannot be accessed
2. WHEN a website blocks scraping, THE Bot SHALL notify the User that the content is protected
3. WHEN the AI API fails, THE Bot SHALL notify the User to try again later
4. WHEN an unexpected error occurs, THE Bot SHALL log the error and notify the User with a generic error message

### Requirement 7: Asynchronous Processing

**User Story:** Как система, я хочу обрабатывать запросы асинхронно, чтобы один долгий запрос не блокировал других пользователей.

#### Acceptance Criteria

1. WHEN processing a request, THE Orchestrator SHALL use Kotlin Coroutines for asynchronous execution
2. WHEN a request is being processed, THE Bot SHALL send a "typing" indicator to the User
3. WHEN multiple Users send requests simultaneously, THE Bot SHALL process them concurrently without blocking

### Requirement 8: Security and Configuration

**User Story:** Как разработчик, я хочу хранить секреты безопасно, чтобы предотвратить утечку API-ключей.

#### Acceptance Criteria

1. WHEN the application starts, THE Bot SHALL read API keys and tokens from environment variables
2. WHEN environment variables are missing, THE Bot SHALL fail to start with a clear error message
3. WHEN making HTTP requests, THE Content_Extractor SHALL use a realistic browser User-Agent header to avoid blocking

### Requirement 9: Bot Commands

**User Story:** Как пользователь, я хочу использовать команды бота, чтобы получить помощь и начать работу.

#### Acceptance Criteria

1. WHEN a User sends /start command, THE Bot SHALL respond with a welcome message and usage instructions
2. WHEN a User sends /help command, THE Bot SHALL respond with detailed usage instructions and examples
3. WHEN a User sends an unsupported command, THE Bot SHALL respond with a message suggesting /help


