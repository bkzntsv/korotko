# Implementation Plan: AI Content Summarizer Bot

## Overview

Реализация Telegram-бота на Kotlin для создания кратких выжимок веб-статей через OpenAI API. Архитектура следует Clean Architecture с использованием Koin для DI, Ktor для HTTP, и Kotest для тестирования.

## Tasks

- [ ] 1. Инициализация проекта и базовая конфигурация
  - Создать Gradle проект с Kotlin DSL
  - Настроить build.gradle.kts с необходимыми dependencies
  - Настроить Shadow plugin для создания fat JAR
  - Создать структуру пакетов: `presentation`, `domain`, `infrastructure`, `config`
  - Настроить Logback для логирования
  - _Requirements: 8.1, 8.2_

- [ ]* 1.1 Написать unit тесты для загрузки конфигурации
  - Тест: конфигурация загружается из environment variables
  - Тест: приложение падает с ошибкой если переменные отсутствуют
  - _Requirements: 8.1, 8.2_

- [ ] 2. Реализовать модели данных и Result wrapper
  - Создать data classes: `ExtractedContent`, `Summary`, `Message`, `Command`
  - Создать sealed class `Result<T>` для обработки ошибок
  - Создать sealed class `SummarizerError` с типами ошибок
  - Создать enum `ParseMode` для Telegram форматирования
  - _Requirements: 1.2, 6.1, 6.2, 6.3, 6.4_

- [ ] 3. Реализовать Configuration и Environment Loading
  - Создать `BotConfig` data class
  - Реализовать `ConfigLoader.loadFromEnv()` с валидацией
  - Добавить поддержку optional переменных (USER_AGENT, LOG_LEVEL, etc.)
  - Обработать `ConfigurationException` при отсутствии обязательных переменных
  - _Requirements: 8.1, 8.2_

- [ ] 4. Checkpoint - Проверка базовой инфраструктуры
  - Убедиться, что проект компилируется
  - Убедиться, что конфигурация загружается корректно
  - Спросить пользователя, если возникли вопросы

- [ ] 5. Реализовать Content Extractor
  - [ ] 5.1 Создать интерфейс `ContentExtractor` и data class `ExtractedContent`
    - Определить suspend функцию `extractContent(url: String): Result<ExtractedContent>`
    - _Requirements: 2.1, 2.2, 2.6_

  - [ ] 5.2 Реализовать `ArticleExtractor` с Jsoup и Readability4J
    - Настроить Ktor HttpClient для скачивания HTML с realistic User-Agent
    - Передать HTML string в Readability4J для извлечения контента
    - Если Readability4J не находит контент, использовать fallback на Jsoup селекторы (`article`, `main`, `.content`, `p`, `h1-h3`)
    - Извлекать title, text, и устанавливать wasTruncated флаг
    - Примечание: Readability4J принимает либо HTML string, либо Jsoup Document
    - _Requirements: 2.1, 2.2, 2.6, 8.3_

  - [ ] 5.3 Добавить валидацию размера контента
    - Проверка минимальной длины (200 символов)
    - Обрезание при превышении максимума (50000 символов)
    - Установка флага `wasTruncated = true` при обрезании
    - _Requirements: 2.3, 2.4_

  - [ ] 5.4 Добавить обработку HTTP ошибок
    - Обработка 403 Forbidden
    - Обработка 404 Not Found
    - Обработка 500+ Server Errors
    - Обработка timeouts
    - _Requirements: 2.5, 6.1, 6.2_

  - [ ]* 5.5 Написать property тест для Content Extractor
    - **Property 4: Content Structure Preservation**
    - **Validates: Requirements 2.2, 2.6**
    - Генерировать HTML с параграфами и заголовками
    - Проверять, что извлеченный текст сохраняет структуру и title
    - _Requirements: 2.2, 2.6_

  - [ ]* 5.6 Написать property тест для User-Agent
    - **Property 10: Realistic User-Agent Header**
    - **Validates: Requirements 8.3**
    - Проверять, что все HTTP запросы содержат realistic User-Agent
    - _Requirements: 8.3_

  - [ ]* 5.7 Написать property тест для валидации длины
    - **Property 12: Content Length Validation**
    - **Validates: Requirements 2.3**
    - Генерировать контент < 200 символов
    - Проверять, что возвращается ошибка
    - _Requirements: 2.3_

  - [ ]* 5.8 Написать property тест для truncation
    - **Property 13: Content Truncation with Notification**
    - **Validates: Requirements 2.4**
    - Генерировать контент > 50000 символов
    - Проверять, что текст обрезается и флаг wasTruncated = true
    - _Requirements: 2.4_

- [ ] 6. Реализовать AI Provider
  - [ ] 6.1 Создать интерфейс `AIProvider` и data class `Summary`
    - Определить suspend функцию `generateSummary(content: ExtractedContent): Result<Summary>`
    - Добавить поле `title` в Summary
    - _Requirements: 3.1, 5.2_

  - [ ] 6.2 Реализовать `OpenAIProvider` с Ktor Client
    - Настроить Ktor HttpClient с JSON serialization
    - Создать системный промпт для суммаризации (ВАЖНО: промпт должен явно содержать слово "JSON" для работы JSON Mode)
    - Использовать model = "gpt-4o-mini"
    - Настроить `response_format: { "type": "json_object" }` для гарантированного JSON ответа
    - _Requirements: 3.1, 3.4, 4.1, 4.2_

  - [ ] 6.3 Добавить парсинг JSON ответа от OpenAI
    - Парсить поля "mainIdea" и "keyPoints"
    - Валидировать структуру ответа (3-5 key points)
    - _Requirements: 3.1_

  - [ ] 6.4 Добавить обработку ошибок AI API
    - Обработка timeout
    - Обработка rate limits
    - Обработка invalid response
    - _Requirements: 3.2, 3.3, 6.3_

  - [ ]* 6.5 Написать unit тест для использования правильной модели
    - Проверить, что используется "gpt-4o-mini"
    - _Requirements: 3.4_

  - [ ]* 6.6 Написать property тест для структуры AI ответа
    - **Property 5: AI Summary Structure**
    - **Validates: Requirements 3.1**
    - Генерировать различные тексты
    - Проверять, что summary содержит mainIdea и 3-5 keyPoints
    - _Requirements: 3.1_

  - [ ]* 6.7 Написать property тест для русского языка
    - **Property 6: Russian Output Language**
    - **Validates: Requirements 4.1, 4.2**
    - Генерировать тексты на разных языках
    - Проверять, что выжимка всегда на русском
    - _Requirements: 4.1, 4.2_

- [ ] 7. Checkpoint - Проверка core компонентов
  - Убедиться, что Content Extractor и AI Provider работают
  - Убедиться, что все тесты проходят
  - Спросить пользователя, если возникли вопросы

- [ ] 8. Реализовать Response Formatter
  - [ ] 8.1 Создать `ResponseFormatter` object
    - Реализовать `formatSummary(summary: Summary, wasTruncated: Boolean): String`
    - Реализовать `formatError(error: SummarizerError): String`
    - _Requirements: 5.1, 5.2, 5.3, 6.1, 6.2, 6.3, 6.4_

  - [ ] 8.2 Реализовать форматирование в Telegram Markdown
    - Добавить emoji (📄, 🔗, ⚠️)
    - Структурировать: Title, Суть, Ключевые тезисы, URL
    - Добавить пометку об обрезании если wasTruncated = true
    - _Requirements: 5.1, 5.2, 5.3, 2.4_

  - [ ] 8.3 Реализовать форматирование ошибок
    - Создать user-friendly сообщения для каждого типа ошибки
    - _Requirements: 6.1, 6.2, 6.3, 6.4_

  - [ ]* 8.4 Написать property тест для форматированного вывода
    - **Property 7: Formatted Output Structure**
    - **Validates: Requirements 5.1, 5.2, 5.3**
    - Генерировать различные Summary объекты
    - Проверять наличие Markdown, URL, title, и секций
    - _Requirements: 5.1, 5.2, 5.3_

- [ ] 9. Реализовать Summary Orchestrator
  - [ ] 9.1 Создать интерфейс `SummaryOrchestrator`
    - Определить suspend функцию `processSummaryRequest(url: String): Result<Summary>`
    - _Requirements: 1.1, 7.1_

  - [ ] 9.2 Реализовать `SummaryOrchestratorImpl`
    - Координировать вызов ContentExtractor -> AIProvider
    - Обрабатывать Result на каждом этапе
    - Использовать Kotlin Coroutines для асинхронности
    - Логировать каждый этап процесса
    - _Requirements: 1.1, 7.1_

  - [ ] 9.3 Добавить обработку ошибок на уровне оркестратора
    - Catch unexpected exceptions
    - Логировать полный stack trace
    - Возвращать SummarizerError.UnknownError
    - _Requirements: 6.4_

- [ ] 10. Реализовать Telegram Bot Controller
  - [ ] 10.1 Создать интерфейс `TelegramBot`
    - Определить suspend функции для обработки сообщений и команд
    - Определить функции для отправки сообщений и индикаторов
    - _Requirements: 1.1, 7.2, 9.1, 9.2_

  - [ ] 10.2 Реализовать `TelegramBotImpl` с telegram-bot-kotlin
    - Настроить bot polling
    - Реализовать обработку входящих updates
    - _Requirements: 1.1, 9.1, 9.2_

  - [ ] 10.3 Реализовать обработку команд /start и /help
    - /start: welcome message с инструкциями
    - /help: детальные инструкции и примеры
    - _Requirements: 9.1, 9.2_

  - [ ] 10.4 Реализовать обработку неизвестных команд
    - Отправлять сообщение с предложением использовать /help
    - _Requirements: 9.3_

  - [ ] 10.5 Реализовать извлечение URL из текстовых сообщений
    - Использовать `message.entities` от Telegram API для надежного определения URL (предпочтительно)
    - Добавить fallback на regex для случаев, когда entities отсутствуют
    - Обрабатывать только первый валидный URL
    - Валидировать формат URL
    - Примечание: Telegram API уже распознает ссылки в entities, это надежнее чем regex
    - _Requirements: 1.1, 1.2, 1.3_

  - [ ] 10.6 Реализовать отправку typing indicator
    - Отправлять "typing..." перед началом обработки
    - _Requirements: 7.2_

  - [ ] 10.7 Реализовать асинхронную обработку запросов
    - Каждый запрос обрабатывать в отдельной корутине
    - Использовать Dispatchers.IO для I/O операций
    - _Requirements: 7.1, 7.3_

  - [ ] 10.8 Интегрировать Orchestrator и ResponseFormatter
    - Вызывать orchestrator.processSummaryRequest(url)
    - Форматировать результат через ResponseFormatter
    - Отправлять форматированный ответ пользователю
    - _Requirements: 1.1, 5.1, 5.2, 5.3_

  - [ ]* 10.9 Написать unit тесты для команд
    - Тест: /start возвращает welcome message
    - Тест: /help возвращает инструкции
    - _Requirements: 9.1, 9.2_

  - [ ]* 10.10 Написать property тест для URL extraction
    - **Property 1: URL Extraction Attempt**
    - **Validates: Requirements 1.1**
    - Генерировать сообщения с валидными URL
    - Проверять, что extraction вызывается
    - _Requirements: 1.1_

  - [ ]* 10.11 Написать property тест для invalid URL
    - **Property 2: Invalid URL Error Handling**
    - **Validates: Requirements 1.2**
    - Генерировать malformed URLs
    - Проверять, что возвращается ошибка
    - _Requirements: 1.2_

  - [ ]* 10.12 Написать property тест для multiple URLs
    - **Property 3: First URL Processing**
    - **Validates: Requirements 1.3**
    - Генерировать сообщения с несколькими URL
    - Проверять, что обрабатывается только первый
    - _Requirements: 1.3_

  - [ ]* 10.13 Написать property тест для typing indicator
    - **Property 8: Typing Indicator**
    - **Validates: Requirements 7.2**
    - Проверять, что typing indicator отправляется перед ответом
    - _Requirements: 7.2_

  - [ ]* 10.14 Написать property тест для concurrent processing
    - **Property 9: Concurrent Request Processing**
    - **Validates: Requirements 7.3**
    - Генерировать множественные одновременные запросы
    - Проверять, что они не блокируют друг друга
    - _Requirements: 7.3_

  - [ ]* 10.15 Написать property тест для unknown commands
    - **Property 11: Unknown Command Response**
    - **Validates: Requirements 9.3**
    - Генерировать неподдерживаемые команды
    - Проверять, что ответ содержит предложение использовать /help
    - _Requirements: 9.3_

- [ ] 11. Checkpoint - Проверка интеграции
  - Убедиться, что все компоненты интегрированы
  - Убедиться, что все тесты проходят
  - Спросить пользователя, если возникли вопросы

- [ ] 12. Настроить Dependency Injection с Koin
  - Создать `appModule` с определениями всех компонентов
  - Настроить single instances для Configuration, HttpClient, Extractors, Providers
  - Настроить DI для Orchestrator и TelegramBot
  - Инициализировать Koin в main функции
  - _Requirements: 8.1_

- [ ] 13. Реализовать main функцию и запуск приложения
  - [ ] 13.1 Создать main() функцию
    - Инициализировать Koin
    - Загрузить конфигурацию
    - Запустить Telegram Bot
    - _Requirements: 8.1, 8.2_

  - [ ] 13.2 Реализовать graceful shutdown handler
    - Добавить `Runtime.getRuntime().addShutdownHook`
    - Закрыть Ktor HttpClient через `.close()`
    - Остановить Telegram Bot
    - Завершить активные корутины
    - Логировать успешное завершение
    - _Requirements: 8.1_

- [ ] 14. Создать README.md с документацией
  - Описание проекта и функциональности
  - Инструкции по установке dependencies
  - Инструкции по настройке environment variables
  - Инструкции по сборке и запуску
  - Примеры использования
  - Описание архитектуры
  - _Requirements: All_

- [ ] 15. Настроить CI/CD с GitHub Actions
  - Создать `.github/workflows/ci.yml`
  - Настроить запуск unit тестов
  - Настроить запуск property-based тестов
  - Настроить сборку fat JAR
  - Настроить upload артефактов
  - ВАЖНО: Использовать **Ktor MockEngine** или **MockWebServer** (OkHttp) для мокирования HTTP запросов в тестах
  - Это позволит тестам работать в GitHub Actions без реальных запросов к OpenAI API и внешним сайтам
  - _Requirements: All_

- [ ] 16. Final Checkpoint - Полная проверка
  - Убедиться, что все тесты проходят (unit + property)
  - Убедиться, что fat JAR собирается успешно
  - Убедиться, что CI/CD pipeline работает
  - Провести ручное тестирование основных сценариев
  - Спросить пользователя о готовности к деплою

## Notes

- Задачи, помеченные `*`, являются опциональными и могут быть пропущены для более быстрого MVP
- Каждая задача ссылается на конкретные requirements для трассируемости
- Checkpoints обеспечивают инкрементальную валидацию
- Property тесты валидируют универсальные correctness properties
- Unit тесты валидируют конкретные примеры и edge cases
- Минимум 100 итераций для каждого property теста
