rootProject.name = "korotko_ochemeto"

